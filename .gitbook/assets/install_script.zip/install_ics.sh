#!/bin/bash

# Copyright 2018-2024 Intrepid Control Systems, Inc.
# Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
# 3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.
# 4. It is forbidden to use this library or derivatives to interface with vehicle networking hardware not produced by Intrepid Control Systems, Inc.
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

set -e

line_to_check='export PATH="$HOME/.pyenv/bin:$PATH"'

echo "Installing dependencies and pyenv..."
sudo apt-get update
sudo apt-get install -y build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev wget curl llvm libusb-1.0-0-dev libncursesw5-dev xz-utils tk-dev libpcap0.8-dev libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev libgl1-mesa-glx libgles2-mesa libegl1-mesa libmtdev1 libcap-dev protobuf-compiler


if ! grep -q "dtparam=i2c_vc=on" /boot/config.txt; then
    echo "dtparam=i2c_vc=on" | sudo tee -a /boot/config.txt
fi

if [ ! -d "$HOME/.pyenv" ]; then
    curl https://pyenv.run | bash
fi

if grep -qxF "$line_to_check" "$HOME/.bashrc"; then
    echo ".bashrc already configured for pyenv."
else
    echo "Configuring pyenv..."
    echo 'export PATH="$HOME/.pyenv/bin:$PATH"' >> ~/.bashrc
    echo 'eval "$(pyenv init --path)"' >> ~/.bashrc
    echo 'eval "$(pyenv init -)"' >> ~/.bashrc
    echo 'eval "$(pyenv virtualenv-init -)"' >> ~/.bashrc
fi


export PATH="$HOME/.pyenv/bin:$PATH"
eval "$(pyenv init --path)"
eval "$(pyenv init -)"
eval "$(pyenv virtualenv-init -)"

if [ -d "$(pyenv prefix 3.9.19)" ]; then
    echo "Python 3.9.19 is installed."
else
    echo "Installing Python 3.9.19 (This may take a while)..."
    pyenv install 3.9.19

    echo "Creating virtual environment vspyx_env..."
    pyenv virtualenv 3.9.19 vspyx_env

    echo "Virtual environment 'vspyx_env' is ready."
fi

# echo "Installing libicsneo..."
# if [ ! -d "$HOME/ics/libicsneo/docs" ]; then
#     git clone https://github.com/intrepidcs/libicsneo.git "$HOME/ics/libicsneo"
# else
#     echo "Directory already exists. Skipping clone."
# fi

echo "Pip installing VspyX..."
$HOME/.pyenv/versions/vspyx_env/bin/python -m pip install -r $HOME/requirements.txt --extra-index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple/

sudo mkdir -p /root/.vspyx/Licenses

set +e
$HOME/.pyenv/versions/vspyx_env/bin/python -c "import vspyx"

sudo cp $HOME/requirements.txt $HOME/ics/
sudo rm $HOME/requirements.txt

echo "VspyX installation successful."
echo "Usage:"
echo "pyenv activate vspyx_env"
echo "Now you can write and execute VspyX python scripts after obtaning a relevent VspyX license from ICS."
